<?php 

require_once 'app/classes/Framework.php';

Framework::init();
