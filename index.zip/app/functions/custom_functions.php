<?php 

// Primera función de prueba custom
function en_custom() {
  return 'ESTOY DENTRO DE CUSTOM_FUNCTIONS.';
}