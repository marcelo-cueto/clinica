<?php include_once "templates/includes/head.php";?>

<body>

<?php include_once "templates/includes/topbar.php";?>

<?php include_once "templates/includes/navbar.php";?> 
<?php include_once "templates/includes/banner.php";?> 
 
  <main id="main">
  <?php include_once "templates/includes/especialidadesini.php";?> 
  <?php include_once "templates/includes/testimonials.php";?> 
  <?php include_once "templates/includes/footer.php";?> 

    

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>